from unittest import TestCase

from jupyterlab_vre.storage.catalog import Catalog


class TestCatalog(TestCase):

    def __init__(self):
        self.c = Catalog

    def test_add_cell(self):
        self.fail()

    def test_delete_cell_from_title(self):
        self.fail()

    def test_get_all_cells(self):
        self.fail()

    def test_add_credentials(self):
        self.fail()

    def test_add_gh_credentials(self):
        self.fail()

    def test_get_gh_token(self):
        self.fail()

    def test_get_credentials_from_username(self):
        self.fail()

    def test_get_credentials(self):
        self.fail()

    def test_get_cell_from_og_node_id(self):
        self.fail()
