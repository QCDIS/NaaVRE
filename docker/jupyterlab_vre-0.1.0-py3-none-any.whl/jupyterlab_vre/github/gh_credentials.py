class GHCredentials:

    token    : str

    def __init__(self, token) -> None:
        self.token = token